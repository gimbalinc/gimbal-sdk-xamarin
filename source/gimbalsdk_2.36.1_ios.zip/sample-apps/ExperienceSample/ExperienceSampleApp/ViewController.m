/**
 * Copyright (C) 2015 Gimbal, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of Gimbal, Inc.
 *
 * The following sample code illustrates various aspects of the Gimbal Experience SDK.
 *
 * The sample code herein is provided for your convenience, and has not been
 * tested or designed to work on any particular system configuration. It is
 * provided AS IS and your use of this sample code, whether as provided or
 * with any modification, is at your own risk. Neither Gimbal, Inc.
 * nor any affiliate takes any liability nor responsibility with respect
 * to the sample code, and disclaims all warranties, express and
 * implied, including without limitation warranties on merchantability,
 * fitness for a specified purpose, and against infringement.
 */
#import <GimbalExperience/GimbalExperience.h>
#import <Gimbal/Gimbal.h>
#import "ViewController.h"


@interface ViewController () <GMBLExperienceManagerDelegate, GMBLPlaceManagerDelegate>

@property (nonatomic) GMBLExperienceManager *experienceManager;
@property (nonatomic) GMBLPlaceManager *placeManager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.experienceManager = [GMBLExperienceManager new];
    self.experienceManager.delegate = self;
    
    self.placeManager = [GMBLPlaceManager new];
    self.placeManager.delegate = self;
    
    [GMBLPlaceManager startMonitoring];
    [GMBLExperienceManager startExperiences];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)experienceManager:(GMBLExperienceManager *)experienceManager presentViewController:(UIViewController *)actionViewController forAction:(GMBLAction *) action {
    [self addAction:action];

    [self.navigationController popToRootViewControllerAnimated:YES];
    [self.navigationController pushViewController:actionViewController animated:YES];
}

- (NSArray *)experienceManager:(GMBLExperienceManager *)experienceManager filterActions:(NSArray *)receivedActions
{
    return receivedActions;
}

- (void)placeManager:(GMBLPlaceManager *)placeManager didBeginVisit:(GMBLVisit *)visit
{
    NSLog(@"Did Enter Place: %@", visit.place);
    [self addPlace:visit.place forEvent:@"Enter" date:visit.arrivalDate];
}

- (void)placeManager:(GMBLPlaceManager *)manager didReceiveBeaconSighting:(GMBLBeaconSighting *)sighting forVisits:(NSArray *)visits
{
    NSLog(@"Beacon Sighting %@, For Visit, %@", sighting, visits);
}

- (void)placeManager:(GMBLPlaceManager *)placeManager didEndVisit:(GMBLVisit *)visit
{
    NSLog(@"Did Exit Place: %@", visit.place);
    [self addPlace:visit.place forEvent:@"Exit" date:visit.departureDate];
}

-(void)addAction:(GMBLAction *)action
{
    NSString *dateString = [NSDateFormatter localizedStringFromDate:action.visit.arrivalDate dateStyle:NSDateFormatterMediumStyle timeStyle:NSDateFormatterMediumStyle];
    NSDictionary *item  = @{@"row1":[@"Received Experience " stringByAppendingString:(action.notificationMessage ? action.notificationMessage : @"")],
                            @"row2":dateString};
    
    [self addItemToTable:item];
    
}
- (void)addPlace:(GMBLPlace *)place forEvent:(NSString *)event date:(NSDate *)date
{
    NSString *dateString = [NSDateFormatter localizedStringFromDate:date dateStyle:NSDateFormatterMediumStyle timeStyle:NSDateFormatterMediumStyle];
    NSDictionary *item = @{@"row1":[NSString stringWithFormat:@"%@ - %@", event, place.name],
                           @"row2":dateString};
    [self addItemToTable:item];
}

- (NSArray *)events
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"events"];
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self events] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    NSDictionary *item = self.  events[indexPath.row];
    cell.textLabel.text = item[@"row1"];
    cell.detailTextLabel.text = item[@"row2"];
    
    return cell;
}

- (void)addItemToTable:(NSDictionary *)item
{
    NSMutableArray *events = [NSMutableArray arrayWithArray:[self events]];
    [events insertObject:item atIndex:0];
    [[NSUserDefaults standardUserDefaults] setObject:events forKey:@"events"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
}


@end
